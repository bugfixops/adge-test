cat: files/coverage.ec: No such file or directory
